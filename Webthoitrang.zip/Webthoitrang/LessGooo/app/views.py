from itertools import product
from unicodedata import category
from django.shortcuts import render, redirect
from django.views import View
from .models import Customer, Product, Cart, OrderPlaced
from .forms import CustomerRegistrationForm, CustomerProfileForm
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth import logout
from django.db.models import Q  
from .models import Customer, Product, Cart, OrderPlaced, STATE_CHOICES
from django.views.decorators.csrf import csrf_exempt
import os
import google.generativeai as genai
from django.http import JsonResponse
import json
#def home(request):
 #return render(request, 'app/home.html')

class ProductView(View):
    def get(self, request):
        topwears = Product.objects.filter(category='TW')
        bottomwears = Product.objects.filter(category='BW')
        mobiles = Product.objects.filter(category='M')
        return render(request, 'app/home.html', {'topwears': topwears, 'bottomwears': bottomwears, 'mobiles': mobiles})


#def product_detail(request):
 #return render(request, 'app/productdetail.html')

class ProductDetailView(View):
    def get(self, request, pk):
        product = Product.objects.get(pk=pk)
        return render(request, 'app/productdetail.html', {'product':product})

def add_to_cart(request):
    if request.user.is_authenticated:
        user = request.user
        product_id = request.GET.get('prod_id')
        quantity = int(request.GET.get('quantity', 1))  # Lấy số lượng từ request, mặc định là 1
        product = Product.objects.get(id=product_id)

        # Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
        cart_item, created = Cart.objects.get_or_create(user=user, product=product)
        if created:
            cart_item.quantity = quantity  # Thêm số lượng ban đầu
        else:
            cart_item.quantity += quantity  # Cộng dồn số lượng nếu sản phẩm đã có trong giỏ hàng
        cart_item.save()

        return redirect('/cart')
    else:
        return redirect('/login')  # Chuyển hướng nếu chưa đăng nhập
def show_cart(request):
    if request.user.is_authenticated:
        user = request.user
        cart_items = Cart.objects.filter(user=user)

        # Tính tổng giá
        total_price = sum(item.product.discounted_price * item.quantity for item in cart_items)

        return render(request, 'app/addtocart.html', {
            'carts': cart_items,
            'total_price': total_price
        })
    else:
        return redirect('/login')  # Chuyển hướng nếu chưa đăng nhập
def remove_from_cart(request, cart_id):
    if request.user.is_authenticated:
        cart_item = Cart.objects.get(id=cart_id, user=request.user)
        cart_item.delete()
        return redirect('/cart')
    else:
        return redirect('/login')
    
def update_cart(request, cart_id):
    if request.method == "POST":
        if request.user.is_authenticated:
            quantity = int(request.POST.get('quantity', 1))  # Lấy số lượng mới từ form
            cart_item = Cart.objects.get(id=cart_id, user=request.user)
            if quantity > 0:
                cart_item.quantity = quantity
                cart_item.save()
                messages.success(request, "Số lượng sản phẩm đã được cập nhật.")
            else:
                messages.error(request, "Số lượng phải lớn hơn 0.")
        else:
            messages.error(request, "Bạn cần đăng nhập để cập nhật giỏ hàng.")
    return redirect('/cart')

def buy_now(request):
 return render(request, 'app/buynow.html')

#def profile(request):
 #return render(request, 'app/profile.html')

def address(request):
 return render(request, 'app/address.html')

def orders(request):
    orders = OrderPlaced.objects.filter(user=request.user)  # Lấy đơn hàng của user hiện tại
    return render(request, 'app/orders.html', {'orders': orders})

#def change_password(request):
 #return render(request, 'app/changepassword.html')
#view của quần nam
def mobile(request, data=None):
    if data is None:  # Nếu không có bộ lọc
        mobiles = Product.objects.filter(category='M')
    elif data == 'LVT':  # Lọc sản phẩm của thương hiệu H&M
        mobiles = Product.objects.filter(category='M', brand='LVT')
    elif data == 'Roadster':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='M', brand='Roadster')
    elif data == 'Gucci':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='M', brand='Gucci')
    elif data == 'Below':  # Lọc sản phẩm có giá dưới 700
        mobiles = Product.objects.filter(category='M', discounted_price__lt=700)
    elif data == 'Above':  # Lọc sản phẩm có giá từ 1000 trở lên
        mobiles = Product.objects.filter(category='M', discounted_price__gte=1000)
    else:  # Trường hợp không khớp
        mobiles = Product.objects.none()  # Không trả về sản phẩm nào
    return render(request, 'app/mobile.html', {'mobiles': mobiles})
#view của áo nam
def mobileao(request, data=None):
    if data is None:  # Nếu không có bộ lọc
        mobiles = Product.objects.filter(category='A')
    elif data == 'LVT':  # Lọc sản phẩm của thương hiệu H&M
        mobiles = Product.objects.filter(category='A', brand='LVT')
    elif data == 'Roadster':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='A', brand='Roadster')
    elif data == 'Gucci':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='A', brand='Gucci')
    elif data == 'Below':  # Lọc sản phẩm có giá dưới 700
        mobiles = Product.objects.filter(category='A', discounted_price__lt=700)
    elif data == 'Above':  # Lọc sản phẩm có giá từ 1000 trở lên
        mobiles = Product.objects.filter(category='A', discounted_price__gte=1000)
    else:  # Trường hợp không khớp
        mobiles = Product.objects.none()  # Không trả về sản phẩm nào
    return render(request, 'app/mobileao.html', {'mobiles': mobiles})
#view của quần nữ
def quannu(request, data=None):
    if data is None:  # Nếu không có bộ lọc
        mobiles = Product.objects.filter(category='BW')
    elif data == 'LVT':  # Lọc sản phẩm của thương hiệu H&M
        mobiles = Product.objects.filter(category='BW', brand='LVT')
    elif data == 'Roadster':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='BW', brand='Roadster')
    elif data == 'Gucci':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='BW', brand='Gucci')
    elif data == 'Below':  # Lọc sản phẩm có giá dưới 700
        mobiles = Product.objects.filter(category='BW', discounted_price__lt=700)
    elif data == 'Above':  # Lọc sản phẩm có giá từ 1000 trở lên
        mobiles = Product.objects.filter(category='BW', discounted_price__gte=1000)
    else:  # Trường hợp không khớp
        mobiles = Product.objects.none()  # Không trả về sản phẩm nào
    return render(request, 'app/mobileqnu.html', {'mobiles': mobiles})

#view của áo nữ
def aonu(request, data=None):
    if data is None:  # Nếu không có bộ lọc
        mobiles = Product.objects.filter(category='C')
    elif data == 'LVT':  # Lọc sản phẩm của thương hiệu H&M
        mobiles = Product.objects.filter(category='C', brand='LVT')
    elif data == 'Roadster':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='C', brand='Roadster')
    elif data == 'Gucci':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='C', brand='Gucci')
    elif data == 'Below':  # Lọc sản phẩm có giá dưới 700
        mobiles = Product.objects.filter(category='C', discounted_price__lt=700)
    elif data == 'Above':  # Lọc sản phẩm có giá từ 1000 trở lên
        mobiles = Product.objects.filter(category='C', discounted_price__gte=1000)
    else:  # Trường hợp không khớp
        mobiles = Product.objects.none()  # Không trả về sản phẩm nào
    return render(request, 'app/mobileanu.html', {'mobiles': mobiles})

#view của túi nam
def tuinam(request, data=None):
    if data is None:  # Nếu không có bộ lọc
        mobiles = Product.objects.filter(category='T')
    elif data == 'LVT':  # Lọc sản phẩm của thương hiệu H&M
        mobiles = Product.objects.filter(category='T', brand='LVT')
    elif data == 'Roadster':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='T', brand='Roadster')
    elif data == 'Gucci':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='T', brand='Gucci')
    elif data == 'Below':  # Lọc sản phẩm có giá dưới 700
        mobiles = Product.objects.filter(category='T', discounted_price__lt=700)
    elif data == 'Above':  # Lọc sản phẩm có giá từ 1000 trở lên
        mobiles = Product.objects.filter(category='T', discounted_price__gte=1000)
    else:  # Trường hợp không khớp
        mobiles = Product.objects.none()  # Không trả về sản phẩm nào
    return render(request, 'app/mobiletuinam.html', {'mobiles': mobiles})

#view của túi nu
def tuinu(request, data=None):
    if data is None:  # Nếu không có bộ lọc
        mobiles = Product.objects.filter(category='F')
    elif data == 'LVT':  # Lọc sản phẩm của thương hiệu H&M
        mobiles = Product.objects.filter(category='F', brand='LVT')
    elif data == 'Roadster':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='F', brand='Roadster')
    elif data == 'Gucci':  # Lọc sản phẩm của thương hiệu Roadster
        mobiles = Product.objects.filter(category='F', brand='Gucci')
    elif data == 'Below':  # Lọc sản phẩm có giá dưới 700
        mobiles = Product.objects.filter(category='F', discounted_price__lt=700)
    elif data == 'Above':  # Lọc sản phẩm có giá từ 1000 trở lên
        mobiles = Product.objects.filter(category='F', discounted_price__gte=1000)
    else:  # Trường hợp không khớp
        mobiles = Product.objects.none()  # Không trả về sản phẩm nào
    return render(request, 'app/mobiletuinu.html', {'mobiles': mobiles})
#def login(request):
#def login(request):
 #return render(request, 'app/login.html')



#def customerregistration(request):
 #return render(request, 'app/customerregistration.html')

class CustomerRegistrationView(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'app/customerregistration.html', {'form':form})

    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congrats! You have registered successfully!')
            form.save()
        return render(request, 'app/customerregistration.html', {'form':form})


def checkout(request):
 return render(request, 'app/checkout.html')


class ProfileView(View):
    def get(self, request):
        form = CustomerProfileForm()
        return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary'})

    def post(self, request):
        form = CustomerProfileForm(request.POST)    
        if form.is_valid():
            # Sử dụng form.save(commit=False) để tạo đối tượng nhưng chưa lưu vào DB
            reg = form.save(commit=False)
            reg.user = request.user  # Gán user hiện tại cho Customer
            reg.save()  # Lưu đối tượng Customer vào DB
            messages.success(request, 'Congrats! Profile updated successfully.')
            print(f"user_id: {request.user.id}")
            print(f"POST data: {request.POST}")
        else:
            messages.error(request, 'Error updating profile. Please check the form.')
        return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary'})


def orderdelivered(request):
        emps = ProfileView.objects.all()
        cou= emps.count()

        return render(request, 'home.html', {'cou':cou,})

def place_order(request):
    user = request.user

    # Kiểm tra khách hàng hiện tại
    customer = Customer.objects.filter(user=user).first()
    if not customer:
        # Nếu không tìm thấy khách hàng, trả về lỗi hoặc điều hướng
        return HttpResponse("Customer record does not exist. Please complete your profile.", status=400)

    cart_items = Cart.objects.filter(user=user)  # Lấy tất cả sản phẩm trong giỏ hàng

    if cart_items.exists():
        for item in cart_items:
            OrderPlaced.objects.create(
                user=user,
                customer=customer,
                product=item.product,
                quantity=item.quantity,
            )
            item.delete()  # Xóa sản phẩm khỏi giỏ hàng sau khi đặt hàng
        messages.success(request, "Your order has been placed successfully!")
    else:
        messages.error(request, "Your cart is empty!")

    return redirect('orders')  # Chuyển hướng đến trang "Đơn hàng"


def custom_logout_view(request):
    logout(request)
    return redirect('login')  # Chuyển hướng đến trang đăng nhập

class SearchView(View):
    def get(self, request):
        query = request.GET.get('q', '')  # Lấy từ khóa tìm kiếm từ tham số 'q'
        results = Product.objects.filter(
            Q(title__icontains=query) | 
            Q(description__icontains=query) | 
            Q(brand__icontains=query)
        )  # Tìm kiếm theo tiêu đề, mô tả hoặc thương hiệu
        return render(request, 'app/search_results.html', {'query': query, 'results': results})
    
def address(request):
    if not request.user.is_authenticated:
        return redirect('login')  # Chuyển hướng nếu chưa đăng nhập

    customer = Customer.objects.filter(user=request.user).first()
    state_choices = STATE_CHOICES  # Truyền danh sách state vào context

    if request.method == 'POST':
        name = request.POST.get('name')
        locality = request.POST.get('locality')
        city = request.POST.get('city')
        state = request.POST.get('state')
        zipcode = request.POST.get('zipcode')

        if customer:
            # Cập nhật thông tin khách hàng
            customer.name = name
            customer.locality = locality
            customer.city = city
            customer.state = state
            customer.zipcode = zipcode
            customer.save()
            messages.success(request, "Address updated successfully!")
        else:
            # Tạo thông tin khách hàng mới
            Customer.objects.create(
                user=request.user,
                name=name,
                locality=locality,
                city=city,
                state=state,
                zipcode=zipcode
            )
            messages.success(request, "Address added successfully!")

        return redirect('address')  # Reload lại trang sau khi lưu

    return render(request, 'app/address.html', {'customer': customer, 'state_choices': state_choices})


    
# Cấu hình API key (thay thế bằng API key của bạn)
genai.configure(api_key="AIzaSyBMtNq1ytBff6wFj-cD0YxW6BE6zUdKuVc")
# Create the model
generation_config = {
  "temperature": 1,
  "top_p": 0.95,
  "top_k": 40,
  "max_output_tokens": 1000000,
  "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
  model_name="gemini-1.5-pro",
  generation_config=generation_config,
)

chat_session = model.start_chat(
  history=[
    {
      "role": "user",
      "parts": [
        "hello\n\n",
      ],
    },
    {
      "role": "model",
      "parts": [
        "Xin chào! Hôm nay tôi có thể giúp gì cho bạn?\n",
      ],
    },
  ]
)

response = chat_session.send_message("INSERT_INPUT_HERE")

print(response.text)
@csrf_exempt
def chatbot(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            user_message = data.get("message", "")

            if not user_message:
                return JsonResponse({"error": "Message is required."}, status=400)

            chat_session = model.start_chat(history=[])
            response = chat_session.send_message(user_message)
            return JsonResponse({"response": response.text})

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    elif request.method == "GET":
        return render(request, 'app/chatbox.html')

    return JsonResponse({"error": "Method not allowed."}, status=405)


